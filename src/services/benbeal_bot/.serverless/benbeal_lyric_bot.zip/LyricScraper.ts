export const getRandomLyricFromPage = (url: string): string => {
    console.log("hello");
    return "Hello World!";
}